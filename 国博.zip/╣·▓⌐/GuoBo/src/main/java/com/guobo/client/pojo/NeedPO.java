package com.guobo.client.pojo;

/**
 * 客户跟进记录持久化对象
 * @author ZLY
 * needId跟进记录对应数据库表的主键id
 * userId该调 跟进记录对应的客户信息主键id
 * content与客户跟进内容
 * insertTime跟进记录的插入时间
 * who跟进人是谁
 * */
public class NeedPO {
    
    private Integer needId;
    private Integer userId;
    private String content;
    private String insertTime;
    private String who;
    
    public Integer getNeedId() {
        return needId;
    }
    public void setNeedId(Integer needId) {
        this.needId = needId;
    }
    public Integer getUserId() {
        return userId;
    }
    public void setUserId(Integer userId) {
        this.userId = userId;
    }
    public String getContent() {
        return content;
    }
    public void setContent(String content) {
        this.content = content;
    }
    public String getInsertTime() {
        return insertTime;
    }
    public void setInsertTime(String insertTime) {
        this.insertTime = insertTime;
    }
    public String getWho() {
        return who;
    }
    public void setWho(String who) {
        this.who = who;
    }
    
}
