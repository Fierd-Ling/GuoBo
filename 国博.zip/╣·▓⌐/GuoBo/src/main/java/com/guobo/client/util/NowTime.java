package com.guobo.client.util;

import java.text.SimpleDateFormat;
import java.util.Date;

public abstract class NowTime {
    
    public static String getNowTime() {
        SimpleDateFormat SDF = new SimpleDateFormat( "yyyy/MM/dd-HH:mm:ss" );
        String NOW_TIME = SDF.format( new Date() );
        return NOW_TIME;
    }

}
