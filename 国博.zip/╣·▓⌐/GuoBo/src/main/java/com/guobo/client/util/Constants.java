package com.guobo.client.util;

/**
 * 常量类
 * @author ZLY
 * */
public abstract class Constants {
    
    public static final String USER_NAME_IS_NULL = "客户姓名不能为空"; 
    public static final String USER_PHONE_IS_NULL = "客户手机号不能为空";
    public static final String USER_NEED_IS_NULL = "客户需求不能为空";
    public static final String ERROR_MASSAGE = "系统内部未知错误，请先退出系统然后从新进入";
    public static final String INSERT_MASSAGE_OK = "添加客户信息成功";
    public static final String UPDATE_USER_MASSAGE_OK = "客户信息更新成功";
    public static final String DELETE_USER_MASSAGE_OK = "用户信息删除成功";
    public static final String CONTENT_IS_NLL = "客户更跟进记录不能为空";
    public static final String CONTENT_INSERT_OK = "客户跟进记录添加成功";
    public static final String INPUT_IS_NULL = "输入内容不能为空";

}
