package com.guobo.client.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.guobo.client.mapper.UserMapper;
import com.guobo.client.pojo.UserPO;
import com.guobo.client.service.UserService;

/**
 * userService 的实现类
 * @author ZLY
 * */
@Service
public class UserServiceImpl implements UserService {
    
    @Autowired
    private UserMapper userMapper;
    /**
     *获取当前所有的客户信息
     *@author ZLY
     *@return List<UserPO>
     **/
    @Override
    public List<UserPO> listUserMassage() {
        return userMapper.listUserMassage();
    }

    /**
     * 通过客户id查找对应客户的详细信息
     * @author ZLY
     * @param int userId
     * @return UserPO
     * */
    @Override
    public UserPO getUserMassageByUserId( int userId ) {
        return userMapper.getUserMassageByUserId( userId );
    }

    /**
     * 添加新的客户信息
     * @author ZLY
     * @param UserPo
     * */
    @Override
    public void insertUserMassage( UserPO userPO ) {
        userMapper.insertUserMassage( userPO );
    }

    /**
     * 修改客户电话和需求
     * @author ZLY
     * @param UserPO
     * */
    @Override
    public void updateUserMassageByUserId( UserPO userPO ) {
        userMapper.updateUserMassageByUserId( userPO ); 
    }

    /**
     * 通过客户删除客户信息
     * @author ZLY
     * @param int userId
     * */
    @Override
    public void deleteUserMassageByUserId( int userId ) {
        userMapper.deleteUserMassageByUserId( userId );
    }
    
    /**
     * 通过管理输入的客户姓名模糊匹配查找客户信息
     * @author ZLY
     * @param String userName
     * @return List<UserPO>
     * */
    @Override
    public List<UserPO> listUserMassageByInputUserName( String userName ) {
        return userMapper.listUserMassageByInputUserName(userName);
 
    }

}
