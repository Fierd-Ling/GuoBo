package com.guobo.client.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.guobo.client.pojo.NeedPO;
import com.guobo.client.pojo.UserDTO;
import com.guobo.client.pojo.UserPO;
import com.guobo.client.service.NeedService;
import com.guobo.client.service.UserService;
import com.guobo.client.util.Constants;
import com.guobo.client.util.NowTime;
import com.guobo.client.util.POJOConverter;

/**
 * 用户信息表操作控制器
 * @author ZLY
 * */
@Controller
@RequestMapping( value = "/")
public class UserController {
    
	private static final Logger LOGGER = LoggerFactory.getLogger( UserController.class );
    @Autowired
    private UserService userService;
    @Autowired
    private NeedService needService;
    
    /**
     * 获取当前所有客户信息
     * @author ZLY
     * @return List<UserPO>
     * */
    @RequestMapping( value = "listUserMassage" , method = RequestMethod.GET )
    public ModelAndView listUserMassage() {
       List<UserPO> AllUserMassage = userService.listUserMassage();
       ModelAndView mav = new ModelAndView( "show" );
       mav.addObject( "AllUserMassage", AllUserMassage );
       return mav;
    }
    
    /**
     * 通过客户id去查找客户信息详情,以及更近记录
     * @author ZLY
     * @param int userId
     * @return UserPO List<NeedPO>
     * */
    @RequestMapping ( value = "getUserMassageByUserId", method = RequestMethod.GET )
    public ModelAndView getUserMassageByUserId( @RequestParam int userId ) {
    	LOGGER.info( "进入了getUserMassageByUserId" );
        UserPO userPO = userService.getUserMassageByUserId( userId );
        ModelAndView mav = new ModelAndView( "particulars" );
        mav.addObject( "USERPO", userPO );
        List<NeedPO> NEEDLIST = needService.listUserNeedByUserId(userId);
        mav.addObject( "NeedLiist", NEEDLIST );
        return mav;
    }
    
    /**
     * 录入新的客户信息
     * @author ZLY
     * @param String userName,userSex,userPhone,userNeed,responsiblePerson
     * @return ModelAndView
     * */
    @RequestMapping( value = "insertUserMassage", method = RequestMethod.POST )
    public ModelAndView insertUserMassage( @RequestParam String userName, String userSex, String userPhone,
            String userNeed, String responsiblePerson ) {
        //客户名不可为空
        if( userName == "" || userName == null ) {
            ModelAndView mav = new ModelAndView( "insertUserMassage" );
            mav.addObject( "userNameError", Constants.USER_NAME_IS_NULL );
            return mav; 
        }
        //客户电话不可为空
        if( userPhone == null || userPhone == "") {
            ModelAndView mav = new ModelAndView( "insertUserMassage" );
            mav.addObject( "userPhoneError", Constants.USER_PHONE_IS_NULL );
            return mav;
        }
        //客户需求不能为空
        if( userNeed == "" || userNeed == null ) {
            ModelAndView mav = new ModelAndView( "insertUserMassage" );
            mav.addObject( "userNeedError", Constants.USER_NEED_IS_NULL );
            return mav; 
        }
        UserDTO userDTO = new UserDTO();
        userDTO.setUserName( userName );
        userDTO.setUserNeed( userNeed );
        userDTO.setUserPhone( userPhone );
        userDTO.setUserSex( userSex );
        userDTO.setResponsiblePerson( responsiblePerson );
        String insertTime = NowTime.getNowTime();
        userDTO.setInsertTime( insertTime );
        UserPO userPO = POJOConverter.userDTOConversionUserPO( userDTO );
        userService.insertUserMassage( userPO );
        ModelAndView mav = new ModelAndView( "insertUserMassage" );
        mav.addObject( "insertMassageOk", Constants.INSERT_MASSAGE_OK );
        return mav;   
    }
    
    /**
     * 修改客户电话和客户需求
     * @author ZLY
     * @param String userPhone userNeed
     * @return ModelAndView
     * */
    @RequestMapping( value = "updateUserMassage", method = RequestMethod.POST)
    public ModelAndView updateUserMassage( @RequestParam String userPhone, String userNeed, int userId) {
      //客户电话不可为空
        if( userPhone == null || userPhone == "") {
            ModelAndView mav = new ModelAndView( "updateUserMassage" );
            mav.addObject( "userPhoneError", Constants.USER_PHONE_IS_NULL );
            return mav;
        }
        //客户需求不能为空
        if( userNeed == "" || userNeed == null ) {
            ModelAndView mav = new ModelAndView( "updateUserMassage" );
            mav.addObject( "userNeedError", Constants.USER_NEED_IS_NULL );
            return mav; 
        }
        UserDTO userDTO = new UserDTO();
        userDTO.setUserId( userId );
        userDTO.setUserPhone( userPhone );
        userDTO.setUserNeed( userNeed );
        UserPO userPO = POJOConverter.userDTOConversionUserPO( userDTO );
        userService.updateUserMassageByUserId( userPO );
        //更新后调到用户信息详情页面提示更新成功
        UserPO userPO2 = userService.getUserMassageByUserId( userId );
        ModelAndView mav = new ModelAndView( "particulars" );
        mav.addObject( "USERPO", userPO2 );
        mav.addObject( "userMassageUpdateOk", Constants.UPDATE_USER_MASSAGE_OK );
        return mav; 
    }
    
    /**
     * 通过用户id删除用户信息
     * @author ZLY
     * @param int userId
     * */
    @RequestMapping( value = "deleteUserMassageByUserId", method = RequestMethod.GET )
    public ModelAndView deleteUserMassageByUserId( @RequestParam int userId ) {
        userService.deleteUserMassageByUserId( userId );
        ModelAndView mav = new ModelAndView( "particulars" );
        mav.addObject( "deleteUserMassage", Constants.DELETE_USER_MASSAGE_OK );
        return mav;  
    }
    
    /**
     * 添加新的客户跟进记录
     * */
    @RequestMapping( value="insertUserNeed", method = RequestMethod.POST )
    public ModelAndView insertUserNeed( @RequestParam int userId, String content, String who) {
       //新添加的跟进记录不能为空
        if( content == "" || content == null) {
            UserPO userPO = userService.getUserMassageByUserId( userId );
            ModelAndView mav = new ModelAndView( "particulars" );
            mav.addObject( "USERPO", userPO );
            mav.addObject( "content", Constants.CONTENT_IS_NLL );
            List<NeedPO> NEEDLIST = needService.listUserNeedByUserId(userId);
            mav.addObject( "NeedLiist", NEEDLIST );
            return mav;
        }
        NeedPO needPO = new NeedPO();
        String insertTime = NowTime.getNowTime();
        needPO.setContent(content);
        needPO.setUserId(userId);
        needPO.setWho(who);
        needPO.setInsertTime(insertTime);
        needService.insertUserNeed(needPO);
        //返回添加结果在页面展示
        UserPO userPO = userService.getUserMassageByUserId( userId );
        ModelAndView mav = new ModelAndView( "particulars" );
        mav.addObject( "USERPO", userPO );
        mav.addObject( "content", Constants.CONTENT_INSERT_OK );
        List<NeedPO> NEEDLIST = needService.listUserNeedByUserId(userId);
        mav.addObject( "NeedLiist", NEEDLIST );
        return mav; 
    }
    
    /**
     * 通过管理输入的客户姓名模糊匹配查找客户信息
     * @author ZLY
     * @param String userName
     * @return ModelAndVie
     * */
    @RequestMapping( value = "listUserMassageByUserName", method = RequestMethod.POST )
    public ModelAndView listUserMassageByUserName( @RequestParam String userName ) {
        String NOW_USER_NAME = "%"+userName+"%";
        List<UserPO> userList =  userService.listUserMassageByInputUserName( NOW_USER_NAME );
        ModelAndView mav = new ModelAndView( "show" );
        mav.addObject( "AllUserMassage", userList );
        return mav;
        
    }
    
    
    
    

}
