package com.guobo.client.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.guobo.client.pojo.NeedPO;

/**
 * guobo_user_need service层操作接口
 * @author ZLY
 * */
@Service
public interface NeedService {
    
    /**
     * 添加新的客户跟进记录
     * @author ZLY
     * @param NeedPO
     * */
    void insertUserNeed( NeedPO needPO );
    
    /**
     * 获取当前客户所有的跟进记录
     * @author ZLY
     * @param int userId
     * @return List<NeedPO>
     * */
    List<NeedPO> listUserNeedByUserId( int userId);

}
