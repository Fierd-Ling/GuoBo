package com.guobo.client.mapper;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.guobo.client.pojo.NeedPO;

/**
 * guobo_user_need数据库表操作接口
 * @author ZLY
 * */
@Repository
public interface NeedMapper {
    
    /**
     * 添加新的客户更近记录
     * @author ZLY
     * @param NeedPO
     * */
    void insertUserNeed( NeedPO needPO );
    
    /**
     * 获取当前客户所有的跟进记录
     * @author ZLY
     * @param int userId
     * @return List<NeedPO>
     * */
    List<NeedPO> listUserNeedByUserId( int userId);
    

}
