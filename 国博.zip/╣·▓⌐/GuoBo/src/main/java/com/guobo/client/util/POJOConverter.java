package com.guobo.client.util;

import com.guobo.client.pojo.NeedDTO;
import com.guobo.client.pojo.NeedPO;
import com.guobo.client.pojo.UserDTO;
import com.guobo.client.pojo.UserPO;

/**
 * 实体转换工具包
 * @author ZLY
 * */
public abstract class POJOConverter {
    
    /**
     * UserPO转换成UserDTO
     * @author ZLY
     * @param UserPO
     * @return UserDTO
     * */
    public static UserDTO userPOConversionsUserDTO( UserPO userPO ) {
        UserDTO userDTO = new UserDTO();
        userDTO.setUserId( userPO.getUserId() );
        userDTO.setUserName( userPO.getUserName() );
        userDTO.setUserSex( userPO.getUserSex() );
        userDTO.setUserPhone( userPO.getUserPhone() );
        userDTO.setInsertTime( userPO.getInsertTime() );
        userDTO.setResponsiblePerson( userPO.getResponsiblePerson() );
        userDTO.setUserNeed( userPO.getUserNeed() );
        return userDTO;
    }
    
    /**
     * UserDTO转换为UserPO
     * @author ZLY
     * @param UserDTO
     * @return UserPO
     * */
    public static UserPO userDTOConversionUserPO( UserDTO userDTO ) {
        UserPO userPO = new UserPO();
        userPO.setInsertTime( userDTO.getInsertTime() );
        userPO.setResponsiblePerson( userDTO.getResponsiblePerson() );
        userPO.setUserId( userDTO.getUserId() );
        userPO.setUserName( userDTO.getUserName() );
        userPO.setUserNeed( userDTO.getUserNeed() );
        userPO.setUserPhone( userDTO.getUserPhone());
        userPO.setUserSex( userDTO.getUserSex() );
        return userPO;
     }
    
    /**
     * NeedPO转换为NeedDTO
     * @author ZLY
     * @param NeedDTO
     * @return NeedPO
     * */
    public static  NeedPO needDTOConversionNeedPO( NeedDTO needDTO ) {
        NeedPO needPO = new NeedPO();
        needPO.setContent( needDTO.getContent() );
        needPO.setInsertTime( needDTO.getInsertTime() );
        needPO.setNeedId( needDTO.getNeedId() );
        needPO.setWho( needDTO.getWho() );
        needPO.setUserId( needDTO.getUserId() );
        return needPO;
    }
    
    /**
     * NeedDTO转换为NeedDTO
     * @author ZLY
     * @param NeedPO
     * @return NeedDTO
     * */
    public static NeedDTO needPOConversionNeedDTO( NeedPO needPO) {
        NeedDTO needDTO = new NeedDTO();
        needDTO.setContent( needPO.getContent() );
        needDTO.setInsertTime( needPO.getInsertTime() );
        needDTO.setNeedId( needPO.getNeedId() );
        needDTO.setUserId( needPO.getUserId() );
        needDTO.setWho( needPO.getWho() );
        return needDTO;
    }
    

}
