package com.guobo.client.pojo;

/**
 * 客户信息传输对象
 * @author ZLY
 * userId表示客户信息在数据库中对应的主键id
 * userName表示客户性别
 * userPhone客户电话
 * userNeed客户需求
 * inserTime录入系统时间
 * responsiblePerson录入人
 * */
public class UserDTO {
    
    private Integer userId;
    private String userName;
    private String userSex;
    private String userPhone;
    private String userNeed;
    private String insertTime;
    private String responsiblePerson;
    public Integer getUserId() {
        return userId;
    }
    public void setUserId(Integer userId) {
        this.userId = userId;
    }
    public String getUserName() {
        return userName;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }
    public String getUserSex() {
        return userSex;
    }
    public void setUserSex(String userSex) {
        this.userSex = userSex;
    }
    public String getUserNeed() {
        return userNeed;
    }
    public void setUserNeed(String userNeed) {
        this.userNeed = userNeed;
    }
    public String getInsertTime() {
        return insertTime;
    }
    public void setInsertTime(String insertTime) {
        this.insertTime = insertTime;
    }
    public String getResponsiblePerson() {
        return responsiblePerson;
    }
    public void setResponsiblePerson(String responsiblePerson) {
        this.responsiblePerson = responsiblePerson;
    }
    public String getUserPhone() {
        return userPhone;
    }
    public void setUserPhone(String userPhone) {
        this.userPhone = userPhone;
    }

}
