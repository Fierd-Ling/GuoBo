package com.guobo.client.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.guobo.client.util.Constants;

 

/**
 * 全局异常处理类
 * @author ZLY
 * */
@ControllerAdvice
@ResponseBody
public class GlobalExceptionHandler {
    
	private static final Logger LOGGER =  LoggerFactory.getLogger(GlobalExceptionHandler.class);
    /**
     * 全局异常处理方法，出现异常返回到统一页面，同时给出用户提示
     * @author ZLY
     * */
    @ExceptionHandler(Exception.class)
    public ModelAndView exceptHandler(Exception e) {
    	LOGGER.info(e.toString());
       ModelAndView mav = new ModelAndView( "myError" );
       mav.addObject("ErrorMassage", Constants.ERROR_MASSAGE);
       return mav;
    }

}
