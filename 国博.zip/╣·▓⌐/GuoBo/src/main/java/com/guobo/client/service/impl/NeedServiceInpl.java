package com.guobo.client.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.guobo.client.mapper.NeedMapper;
import com.guobo.client.pojo.NeedPO;
import com.guobo.client.service.NeedService;

/**
 * NeedService的实现类
 * @author ZLY
 * */
@Service
public class NeedServiceInpl implements NeedService {
    
    @Autowired
    private NeedMapper needMapper;

    /**
     * 插入新的客户跟进记录
     * @author ZLY
     * @param NeedPO
     * */
    @Override
    public void insertUserNeed(NeedPO needPO) {
        needMapper.insertUserNeed(needPO);
    }


    /**
     * 获取当前客户所有的跟进记录
     * @author ZLY
     * @param int userId
     * @return List<NeedPO>
     * */
    @Override
    public List<NeedPO> listUserNeedByUserId(int userId) {
        return needMapper.listUserNeedByUserId(userId);
    }

 

}
