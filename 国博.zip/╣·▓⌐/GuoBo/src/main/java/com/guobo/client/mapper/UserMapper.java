package com.guobo.client.mapper;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.guobo.client.pojo.UserPO;

/**
 * guobo_user(客户信息表)操作接口
 * @author ZLY
 * */
@Repository
public interface UserMapper {
    
    /**
     * 获取当前所有客户信息
     * @author ZLY
     * @return List<UserPO>
     * */
    List<UserPO> listUserMassage();
    
    /**
     * 通过客户id去查找客户信息
     * @author ZLY
     * @param int userId
     * @return UserPO
     * */
    UserPO getUserMassageByUserId( int userId );
    
    /**
     * 添加新的客户信息
     * @author ZLY
     * @param UserPO
     * */
    void insertUserMassage( UserPO userPO);
    
    /**
     * 修改客户的电话和需求
     * @author ZLY
     * @param UserPO
     * */
    void updateUserMassageByUserId( UserPO userPO);
    
    /**
     * 通过客户id删除客户信息
     * @author ZLY
     * @param int userId
     * */
    void deleteUserMassageByUserId( int userId);
    
    /**
     * 通过管理输入的客户姓名模糊匹配查找客户信息
     * @author ZLY
     * @param String userName
     * @return List<UserPO>
     * */
    List<UserPO> listUserMassageByInputUserName( String userName);

}
